const Logo = () => (
  <img
    src="/assets/2PayLogo.jpg"
    alt=""
    width={80}
    style={{ marginTop: 20, marginBottom: 10, marginLeft: 20 }}
  />
);

export default Logo;
