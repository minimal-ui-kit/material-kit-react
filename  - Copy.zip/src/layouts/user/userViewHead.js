export const UserHeader = {
  SubScriber_Name: 'Jaydon Frankie',
  CAF_NO: '0001',
  Customer_ID: '00000001',
  Gender: 'Male',
  Mobile: '8282919299',
  Email: 'Jaydon@planetcast.net',
  Zip: '401203',
  Zone: 'Baramati',
  City: 'Baramati',
  Operator: 'Dish Media Network Lts',
};

export const UserHeader2 = [
  {
    title: 'CAF NO',
    Data: '0001',
  },
  {
    title: 'SubScriber Name',
    Data: 'ALEX GOMES',
  },
  {
    title: 'Customer ID',
    Data: '00000001',
  },
  {
    title: 'Gender',
    Data: 'Male',
  },
  {
    title: 'Email',
    Data: 'ALEX@planetcast.net',
  },
  {
    title: 'Mobile No',
    Data: '8282919299',
  },
  {
    title: 'Phone No',
    Data: '....',
  },
  {
    title: 'Zip Code',
    Data: '400000',
  },
  {
    title: 'Zone',
    Data: 'Germany',
  },
  {
    title: 'City',
    Data: 'Germany',
  },
  {
    title: 'Operator/Area/Society',
    Data: 'Dish Media Network Lts,Germany,Germany',
  },
  {
    title: 'Subscriber Type',
    Data: 'Office Use',
  },
  {
    title: 'Classcification',
    Data: 'SIM TV',
  },
  {
    title: 'Account Manager',
    Data: '---',
  },
];
